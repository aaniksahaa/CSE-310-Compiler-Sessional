flex -o 2005001.cpp 2005001.l
g++ 2005001.cpp -lfl -o 2005001.out
./2005001.out input.txt
